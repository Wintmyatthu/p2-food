Bicycle=['giant','trek','Specialized','Cannondale','sCOTT']
print(Bicycle[0].title())
print(Bicycle[2].upper())
print(Bicycle[4].swapcase())

print(Bicycle[0].title()+':The largest bike manufacturer in the world, known for its high-quality and innovative products.')

print('\n')

print(Bicycle[2]+':A California-based bike brand that focuses on performance and technology, especially in the mountain bike and road bike segments.')

print('\n')

print(Bicycle[2]+':A Swiss bike brand that produces some of the lightest and fastest bikes in the market, especially in the road and mountain bike categories.')

print('\n')

message= f'My first bicycle was {Bicycle[0].title()}.'
print(message)
