"""import turtle as r
r.title('Hexagon')
r.pensize(5)
r.bgcolor('black')
r.pencolor('blue')
for i in range(0,6):
    r.forward(50)
    r.left(60)
r.right(60)
r.done()"""

"""bottom=int(input('Input a number for the bottom line :'))

print('\n')

import turtle as r
r.title('Triangle')
r.pensize(5)
r.bgcolor('black')
r.pencolor('blue')
for i in range(0,2):
    r.forward(bottom)
    r.left(90)
r.left(45)
H=(bottom**2+bottom**2)**0.5
r.forward(H)
r.done()"""

"""import turtle as r
r.title('Drawing shapes!')
r.bgcolor('black')
r.pencolor('blue')
for i in range(0,8):
    r.forward(50)
    r.left(45)
r.right(45)
r.done()"""

"""import turtle as r
r.title('Pentagon')
r.pensize(5)
r.bgcolor('black')
r.pencolor('blue')
for i in range(0,5):
    r.forward(100)
    r.left(72)
r.right(72)
r.done()"""

"""angle=360/6
import turtle as r
r.pensize(5)
r.title('Polygon')
r.bgcolor('black')
r.pencolor('blue')
for i in range(0,7):
    r.forward(99)
    r.left(angle)
r.right(angle)
r.done()"""

"""angle=360/12
import turtle as r
r.pensize(2)
r.title('Polygon')
r.bgcolor('black')
r.pencolor('blue')
for i in range(0,12):
    r.forward(95)
    r.left(angle)
r.right(angle)
r.done()"""





    