planet=['Mercury','Venus','Earth','Mars','Jupiter','Saturn','Uranus','Neptune']

planett=list(('Mercury','Venus','Earth','Mars','Jupiter','Saturn','Uranus','Neptune'))
#print(type(planet))
#print(len(planet))

#print(type(planett))

#print(planet[0])
#print(planet[4:8])

##Replace
planet[2]='World'
print(planet)

##append
planett.append('Pluto')
print(planett)

