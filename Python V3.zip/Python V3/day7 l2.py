banana=5
guava=3
apple=6
print((banana==4)or(guava==2)and(apple==6))

#print((banana==6)or(guava==3)or(apple==6))