#print(69+1)
#print(7+2)
#print(60+99)
#print(7-9)
#print(9/3)
#print(8*8)
#print(9//9)
#print(99%10)
#print(90**7)

#print(type(69+1))
#print(type(7+2))
#print(type(60+99))
#print(type(7-9))
#print(type(9/3))
#print(type(8*8))
#print(type(9//9))
#print(type(99%10))
#print(type(90**7))

#print(10/5)
#print(int(10/5))

#x=69
#print(type(x))

num1=25
num2=5
#print(num1+num2)
#print(num1-num2)
#print(num1 /num2)
#print(num1*num2)
#print(num1//num2)
#print(num1**num2)
#print(num1%num2)

add=(num1+num2)
sub=(num1-num2)
div=(num1/num2)
multi=(num1*num2)

#print(add)
#print(sub)
#print(div)
#print(multi)

#print('Hello guys, welcome back to my minecraft server!' , 'White guy, are u deaf, I am a pimp named slip back')


#print('ba'+'llon')
#print('he','is very clever')
#print('Hey'+',young man!','How to get to the','hospital?','Just get on the road')

print('Hi '*20)
print('Hi \n'*20)
print(20*'Hi ')
 

