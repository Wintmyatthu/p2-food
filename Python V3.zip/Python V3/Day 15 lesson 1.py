"""X=int(input('Input a number! :'))

print('The Table of',X,'.')
for x in range(1,13):
    for num in range(0,1):
        NUM=X*x
        print(NUM,end=' ')
print()"""
y=' '
for X in range(1,4):
    for x in range(1,4):
        print(x,y,X)
print()
        
