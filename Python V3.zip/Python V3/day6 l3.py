print(6==5)
print(100>=99)
print(100!=90)
print('hhw'=='HHW')