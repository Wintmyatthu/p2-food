
for i in range (10):
    print('Hi Guys!')

print('\n')

for i in range (5):
    print(3)
print('\n')

print('Ask me about dinosaurs.\n Write What are dinosaurs? to find out!')
dino=input('Write here!: ')
if dino=='What are dinosaurs?':
    print('\n Dinosaurs are a diverse group of reptiles [note 1] of the clade Dinosauria. They first appeared during the Triassic period, between 243 and 233.23 million years ago (mya), although the exact origin and timing of the evolution of dinosaurs is a subject of active research.')
else:
    print('Invaild Question!')

print('\n')

for i in range (1,16):
    print(i)
print('\n')

for i in range (2,101,2):
    print(i)
print('\n')

for x in range (8,100,8):
    print(x)
print('\n')

for y in range (12,100,12):
    print(y)
print('\n')