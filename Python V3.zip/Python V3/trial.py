##    Python 3.11.3 (tags/v3.11.3:f3909b8, Apr  4 2023, 23:49:59) [MSC v.1934 64 bit (AMD64)] on win32
##    Type "help", "copyright", "credits" or "license()" for more information.
##    print("steve")
##    steve
##    print("how_is_Steve")
##    how_is_Steve
##    print("What?")
##    What?
##    print("Unknown:I said who is Steve")
##    Unknown:I said who is Steve
##    print("Steve:Who are you")
##    Steve:Who are you
##    print("I am Ropter")
##    I am Ropter
##    print("Ropter: I am from a plantet (R89)")
##    Ropter: I am from a plantet (R89)
##    print("My duty is to find you and bring to back to my client")
##    My duty is to find you and bring to back to my client
##    print("Steve:Who is your client?")
##    Steve:Who is your client?
##    print(" That is an information that you cannot access!")
##     That is an information that you cannot access!
##    print("Steve:What is your code?")
##    Steve:What is your code?
##    print("Ropter:My code is ('456')")
##    Ropter:My code is ('456')
##    print(456)
##    456
##    print("Steve:Help!")
##    Steve:Help!
##
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##    Unknow:Stopp you goofy ahh dump ass simp
##    Ropter456:You goofy
##
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##    Unknow:Stopp you goofy ahh dump ass simp
##    Ropter456:You goofy
##    You bloody bloody you
##
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##    Unknow:Stopp you goofy ahh dump ass simp
##    Ropter456:You goofy
##    You bloody bloody you
##    x
##
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##    Unknow:Stopp you goofy ahh dump ass simp
##    Ropter456:You goofy
##    You bloody bloody you
##    x
##    66
##
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##    Unknow:Stopp you goofy ahh dump ass simp
##    Ropter456:You goofy
##    You bloody bloody you
##    x
##    66
##    Traceback (most recent call last):
##      File "C:/Users/HP/OneDrive/Documents/Python V3/My second start.py", line 10, in <module>
##        print(print)
##    TypeError: 'int' object is not callable
##
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##    Unknow:Stopp you goofy ahh dump ass simp
##    Ropter456:You goofy
##    You bloody bloody you
##    x
##    66
##    Traceback (most recent call last):
##      File "C:/Users/HP/OneDrive/Documents/Python V3/My second start.py", line 10, in <module>
##        print(print)
##    TypeError: 'int' object is not callable
##
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##    Unknow:Stopp you goofy ahh dump ass simp
##    Ropter456:You goofy
##    You bloody bloody you
##    x
##    66
##    69
##
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##    Unknow:Stopp you goofy ahh dump ass simp
##    Ropter456:You goofy
##    You bloody bloody you
##    x
##    66
##    you are really sus
##    >>> 
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##    Unknow:Stopp you goofy ahh dump ass simp
##    Ropter456:You goofy
##    You bloody bloody you
##    x
##    66
##    69
##    you are really sus
##    >>> 
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##    Unknow:Stopp you goofy ahh dump ass simp
##    Ropter456:You goofy
##    You bloody bloody you
##    x
##    66
##    69
##    you are really sus
##    Traceback (most recent call last):
##      File "C:/Users/HP/OneDrive/Documents/Python V3/My second start.py", line 14, in <module>
##        print(type(Ropter456))
##    NameError: name 'Ropter456' is not defined
##    >>> 
##    ==== RESTART: C:/Users/HP/OneDrive/Documents/Python V3/My second start.py ===
##    Ropter456:Hello guys welcome back to my minecraft server
##    Unknow:Stopp you goofy ahh dump ass simp
##    Ropter456:You goofy
##    You bloody bloody you
##    x
##    66
##    69
##    you are really sus
##    Traceback (most recent call last):
##      File "C:/Users/HP/OneDrive/Documents/Python V3/My second start.py", line 14, in <module>
##        print(type(Ropter456))
##    NameError: name 'Ropter456' is not defined

"""sdr='Hello World!'
print (sdr[0])

Str='Hello World!'
print(Str[2:])

Str='Hello World!'
print(Str*2)"""

l=['abcd',786,2.23,'john',70.2]
L=[123,'john']
print(l+L)

print([1,2,3]+[4,5,6])

for i in range(4):
    print(0.1+i*0.25)












