#a='Yangon'
#print(a)
#print(a.upper())
#print(a.lower())
#print(a.replace('Yangon','New York'))
print(8/8*8)
print(str8/8*8)
print(9-2+40)
