count=[1,2,3,4,5]
print(count)
count.reverse()
print(count)

print('\n')

games=['Minecraft','Monster legends','Blox Fruit','FC Mobile 24']
print(games)
games.reverse()
print(games)
