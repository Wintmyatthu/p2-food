x=1.9999999
#print(type(x))
y=98
#print(type(y))
z=6/9
#print(type(z))
t=('ropter')
#print(type(t))
R=9
#print(type(R))
#print(type('Ropter'))
r=9+9j
#print(type(r))
e=6+9j
#print(type(e))
ro=True
#print(type(ro))
tt=True
#print(type(tt))
tth=False
#print(type(tth))
#print('TTH=oof')
soof=68+1
#print(type(oof))

X=['apple','orange','dog']
#print(type(X))

Y=('Lamborghini Aventador SVJ','Chelsea','Manchster City')
#print(type(Y))

print('I am Aung Phone Htet.\n''People also call me as Ropter and Giga Chad.\n'"I am 13 years old.")
print('I am Aung Phone Htet.\n''\tPeople also call me as Ropter and Giga Chad.\n'"\t\tI am 13 years old.")

      









      








