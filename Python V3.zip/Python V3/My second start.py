print("Ropter456:Hello guys welcome back to my minecraft server")
print('Unknow:Stopp you goofy ahh dump ass simp')
print("Ropter456:You goofy")
#print("Ropter456:You goofy")
print("You bloody bloody you")
x=66
print("x")
print(x)

x=x+3
print(x)
print('you are really sus')

print(type(Ropter456))






