b='How are you?'
#print(b)
#print(b[:])
#print(b[-1])
print(b[-4:-1])
#print(b[-4:])

print(b[-1:-4])

