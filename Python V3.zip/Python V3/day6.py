#food=input('What would you like to eat sir?')
#drink=input('What would you like to drink sir?')
#bill=input('What is the total cost sir?')
#table=input('What table am I suppost to deliver the food sir?' )
#print('\n')
#print('I have order from table %s .They order %s and %s. The cost is %s.' %(table,food,drink,bill))

#a=input('Enter the first number.')
#b=input('Enter the second number.')
#print('\n')

#x=min(a,b)

#y=max(a,b)

#print('Minimum number is '+x+('.'))
#print('Maximum number is',y+('.'))

R=float(input('Enter the first number.'))
r=float(input('Enter the second number.'))
Y=float(input('Enter the third number.'))
y=float(input('Enter the fourth number.'))
E=float(input('Enter the fifth number.'))
e=float(input('Enter the sixth number.'))

print('\n')

z=min(R,r,Y,y,E,e)
x=max(R,r,Y,y,E,e)

print('Minimum number is ',z,('.'))
print('Maximum number is ',x,('.'))




