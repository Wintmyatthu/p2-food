x=str(3)
#print(type(x))
y=int(9)
#print(type(y))
z=float(8)
#print(type(z))
t=('Ropter456','Monster legends',"Minecraft")
#print(type(t))
r=['Foden','Man U',"losing"]
#print(type(r))

import random
print(random.randrange(98,968))

