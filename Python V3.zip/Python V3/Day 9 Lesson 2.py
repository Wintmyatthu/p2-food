print('⚽️ '*3+'\n')
print('Hello Guys! '*2+'\n')
print('World Cup!! '*4+'\n')
print('Let'+'s play football!','World Cup!! '*4+'\n')
print('⚽️ '*3+'\n')

