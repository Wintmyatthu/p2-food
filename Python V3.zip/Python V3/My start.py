print("steve")
steve
print("how_is_Steve")
how_is_Steve
print("What?")
What
print("Unknown:I said who is Steve")
Unknown:I said who is Steve
print("Steve:Who are you")
Steve:Who are you
print("I am Ropter")
I am Ropter
print("Ropter: I am from a plantet (R89)")
Ropter: I am from a plantet (R89)
print("My duty is to find you and bring to back to my client")
My duty is to find you and bring to back to my client
print("Steve:Who is your client?")
Steve:Who is your client?
print(" That is an information that you cannot access!")
 That is an information that you cannot access!
print("Steve:What is your code?")
Steve:What is your code?
print("Ropter:My code is ('456')")
Ropter:My code is ('456')
print(456)
456
print("Steve:Help!")
Steve:Help!


