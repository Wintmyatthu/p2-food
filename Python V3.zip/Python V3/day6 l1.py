alp='abcdefghijklmnopqrstuvwxyz'

#print(alp)
#print(type(alp))
#print(len(alp))
#print(alp[0])
print(alp[7])
print(alp[19])
print(alp[0])
print(alp[24])

print(alp[19])
print(alp[7])
print(alp[0])
print(alp[13])
print(alp[10])
print(alp[24])
print(alp[14])
print(alp[20])
