"""import turtle as r
r.title('Drawing a star shape')
r.bgcolor('black')
r.pencolor('blue')
r.pensize(5)
r.penup()
r.goto(-50,0)
r.pendown()
for i in range(5):
    r.fd(50)
    r.rt(144)
r.lt(144)

r.pencolor('hotpink')
r.penup()
r.goto(300,200)
r.pendown()
for i in range(5):
    r.fd(50)
    r.rt(144)
r.lt(144)

r.pencolor('linen')
r.penup()
r.goto(-300,-200)
r.pendown()
for i in range(5):
    r.fd(50)
    r.rt(144)
r.lt(144)

r.pencolor('darkorange')
r.penup()
r.goto(-300,200)
r.pendown()
for i in range(5):
    r.fd(50)
    r.rt(144)
r.lt(144)

r.pencolor('khaki')
r.penup()
r.goto(300,-200)
r.pendown()
for i in range(5):
    r.fd(50)
    r.rt(144)
r.lt(144)

r.pencolor('magenta')
r.penup()
r.goto(300,100)
r.pendown()
for i in range(5):
    r.fd(50)
    r.rt(144)
r.lt(144)

r.pencolor('purple')
r.penup()
r.goto(-300,100)
r.pendown()
for i in range(5):
    r.fd(50)
    r.rt(144)
r.lt(144)

r.pencolor('cyan')
r.penup()
r.goto(300,-100)
r.pendown()
for i in range(5):
    r.fd(50)
    r.rt(144)
r.lt(144)

r.pencolor('gold')
r.penup()
r.goto(-300,-100)
r.pendown()
for i in range(5):
    r.fd(50)
    r.rt(144)
r.lt(144)


r.pencolor('yellow')
r.penup()
r.goto(400,-100)
r.pendown()
for i in range(5):
    r.fd(50)
    r.rt(144)
r.lt(144)

r.pencolor('silver')
r.penup()
r.goto(-400,-100)
r.pendown()
for i in range(5):
    r.fd(50)
    r.rt(144)
r.lt(144)

r.pencolor('dimgray')
r.penup()
r.goto(400,100)
r.pendown()
for i in range(5):
    r.fd(50)
    r.rt(144)
r.lt(144)"""

"""import turtle as r
p=['blue','red','gold','blue','cyan']
r.title('Drawing a star shape')
r.bgcolor('black')
r.pensize(5)
r.penup()
r.goto(-50,0)
r.pendown()
for i in range(5):
    r.pencolor(p[i])
    r.fd(50)
    r.rt(144)



import turtle as r
r.title('Drawing a star shape')
r.bgcolor('black')
r.pensize(5)
r.penup()
r.goto(300,200)
r.pendown()
for i in range(5):
    r.pencolor(p[i])
    r.fd(50)
    r.rt(144)



import turtle as r
r.title('Drawing a star shape')
r.bgcolor('black')
r.pensize(5)
r.penup()
r.goto(-300,-200)
r.pendown()
for i in range(5):
    r.pencolor(p[i])
    r.fd(50)
    r.rt(144)



import turtle as r
r.title('Drawing a star shape')
r.bgcolor('black')
r.pensize(5)
r.penup()
r.goto(-300,200)
r.pendown()
for i in range(5):
    r.pencolor(p[i])
    r.fd(50)
    r.rt(144)



import turtle as r
r.title('Drawing a star shape')
r.bgcolor('black')
r.pensize(5)
r.penup()
r.goto(300,-200)
r.pendown()
for i in range(5):
    r.pencolor(p[i])
    r.fd(50)
    r.rt(144)

r.lt(144)"""
import turtle as r

def hex():
        r.bgcolor('black')
        r.pencolor('blue')
        r.penup()
        r.pendown()
        for i in range(0,6):
            r.forward(70)
            r.left(60)
hex()

def hex():
        r.pencolor('blue')
        r.penup()
        r.pendown()
        for i in range(0,6):
            r.forward(70)
            r.rt(60)
hex()

def hex():
        r.pencolor('blue')
        r.penup()
        r.pendown()
        for i in range(0,6):
            r.forward(70)
            r.rt(60)
hex()

