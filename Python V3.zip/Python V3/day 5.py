#R=input('What is your name :' )
#print(R)
#print('My name is', R +".")
#Y=input('What is your name :')
#print(Y)
#print('My name is', Y +".")
#A=input('How old are you :')
#print(A)
#print('I am', A +  '  years old.')

#R=47
#r=int(input('Enter second number  :'))
#print('First number is   ',R)
#print('Second number is   ',r)
#print('Addition =',R+r)
#print('Subtraction =',R-r)
#print('Division =',R/r)
#print('Multiplication =',R*r)
#print('Modulus =',R%r)

#T=int(input('Enter first number        :'))
#t=int(input('Enter second number  :'))
#print('First number is   ',T)
#print('Second number is   ',t)
#print('Addition =',T+t)
#print('Subtraction =',T-t)
#print('Division =',T/t)
#print('Multiplication =',T*t)
#print('Modulus =',T%t)

name=input('What is your name?   :')
age=input('how old are you   :')
eyecolour=input('What is your eye colour?   :')
Year=input('What Year are you attending?   :')
Humanlevel=input('What is your human level?   :')
hobby=input('What are your hobbies?   :')
dreamjob=input('What is your dream job?   :')

print('\n')

print('Hello my friend.')
print('My name is', name+'.')
print('I am', age+' years old.')
print('My eye colour is', eyecolour+'.')
print('I am in Year',Year+ '.')
print('I am a',Humanlevel +'.')
print('I likes playing', hobby+'.')
print('My dream job is', dreamjob+'.')

print('\n')

print('Hello my friend, My name is %s. I am %s years old. My eye colour is %s. I am in Year %s. I am a %s. I likes playing %s.  My dream job is %s.'  %(name,age,eyecolour,Year,Humanlevel,hobby,dreamjob))



