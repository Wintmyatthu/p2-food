input(x=9)
print(x)
