EV_cars=['Tesla','Honda','Toyota','Nissa']
Gas_cars=['Misubishi','Chevrolet','Mazda']
Old_cars=['Lamborghini','Ferrari','Fiat']
All_cars=[EV_cars,Gas_cars,Old_cars]

print(EV_cars)

print('\n')

print(Gas_cars)

print('\n')

print(Old_cars)

print('\n')

print(All_cars)

print('\n')

EV_cars.reverse()
Gas_cars.reverse()
Old_cars.reverse()
All_cars.reverse()

print(EV_cars)

print('\n')

print(Gas_cars)

print('\n')

print(Old_cars)

print('\n')

print(All_cars)

print('\n')

print(All_cars[1][2])

print('\n')

small_birds=['hummingbird','finch']
extinct_birds=['dodo','passenger pigeon','Newigean Blue']
carol_birds=[3,'French hens',2,'turtledoves']
all_birds=[small_birds,extinct_birds,carol_birds]
print(small_birds)
print('\n')
print(extinct_birds)
print('\n')
print(carol_birds)
print('\n')
print(all_birds)
