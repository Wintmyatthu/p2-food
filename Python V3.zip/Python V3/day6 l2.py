b='This is my favourite fruit'

print(len(b))
#print(b[25])
#print(b)
print(b[:])
print(b[0:4])
print(b[5:7])

q='apple banana guava orange'