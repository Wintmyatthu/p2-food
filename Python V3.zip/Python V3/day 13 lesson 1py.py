"""num=int(1)
for x in range (5,61,5):
    print('5 ×',num,'=', x)
    num=num+1

print('\n')"""

print('Top 5 favourite games of boys')
sth=input(str('Are you ready! y/n :'))

if sth=='y':
    T5FGB=['1. Blox Fruits','2. Flag Wars','3. Minecraft','4. FC Mobile 24','5. Monster Legends']
    print(T5FGB)
    for y in T5FGB:
     print(y)
else:
    print('Syntex Error!')
    
print('\n')

for gm in range(0,2):
    for hello in range(0,2):
        print('Hello')
    print('Good Morning!')
    
print('\n')
    
for hi in range(0,2):
    for why in range(0,3):
        print('Hello')
    for Why in range(0,2):
        print('hip')


