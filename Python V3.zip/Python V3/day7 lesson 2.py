#b='This is my favourite game!'
#print(len(b))
#print(b)
#print(b[0:4])
#print(b[5:8])
#print(b[8:11])
#print(b[11:20])
#print(b[21:25])
#print('!')

R='What is up bro!'
print(R[0:4])
print(R[5:7])
print(R[8:10])
print(R[11:15])

print('\n')

G='Would you like to play Blox Fruit with me?'
print(G[0:5])
print(G[6:9])
print(G[10:14])
print(G[15:17])
print(G[18:22])
print(G[23:27])
print(G[28:33])
print(G[34:38])
print(G[39:42])

print('\n')

A='Hell yaa!'
print(A[0:4])
print(A[5:9])