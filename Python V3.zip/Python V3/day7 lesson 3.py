print('6<9')
print(6<9)


print('\n')

print('9>6')
print(9>6)

print('\n')

print('100==99')
print(100==99)

print('\n')

print('65==44')
print(65==44)

print('\n')

print('7>=0')
print(7>=0)

print('\n')

print('55!=5')
print(55!=5)
