"""import turtle as t
t.pencolor('black')
t.pensize(3)
t.forward('50')
t.rt('45')"""

"""print(5)
print(type(5))
print(5.0)
print(type(5.0))
a=print('My clever student')
print(type('My clever student'))
print('500')
print(type('500'))

print('\n')

R=9
print(R)
r=float(R)
print(r)
n=str(R)
e='World Cup!'
print(len(e))
print(e[-1])
print(e.replace(e,'Football!'))
print(e.upper())
print(e.lower())
print(e.capitalize())

num1=100
num2=100
add=print(num1+num2)
sub=print(num1-num2)
multi=print(num1*num2)
multi2=print(num1**num2)
div=print(num1/num2)
div2=print(num1//num2)
div3=print(num1%num2)


a='World'
b=' Cup!'
WC=a+b
print(WC)
R=print('2026',a+b)"""

a='Dog'
b=7
print(a,b)
print(a*b)
print(b*a)


