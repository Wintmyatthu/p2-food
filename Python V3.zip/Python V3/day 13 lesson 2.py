"""import turtle as t
for hi in range(0,4):
    for why in range(0,1):
        t.forward(200)
    for Why in range(0,1):
        t.left(90)
t.done()"""

"""import turtle as t
for i in range(0,2):
    for y in range(0,1):
        t.forward(200)
    for Hy in range(0,1):
        t.left(90)
    for hy in range(0,1):
        t.forward(100)
    for j in range (0,1):
        t.left(90)
t.right(90)
t.done()"""

"""import turtle as t
for i in range(0,360):
    for y in range(0,1):
        t.forward(2)
    for Hy in range(0,1):
        t.left(1)
t.right(1)
t.done()"""

"""import turtle as t
for i in range(0,2):
    for y in range(0,1):
        t.forward(200)
    for Hy in range(0,1):
        t.left(90)
t.left(45)
for I in range(0,2):
    for y in range(0,1):
        t.forward(285)
t.right(1)
t.done()"""

import turtle as t
t.title('Making a circle.')
t.speed(10)
t.pensize(100)
t.pencolor('orchid')
t.bgcolor('black')
t.shape('turtle')
t.fillcolor("grey")
t.begin_fill()
t.circle(130)
t.end_fill()
t.done()



