R='a man with a plan'

#print(R.title())
#print(R.capitalize())
#print(R.upper())
#print(R.lower())

#print('\n')

r='A man With A PLAN'
#print(r.swapcase())

#print('\n')

#print(r.replace('m','M'))
#print(R.replace('w','W'))

#print(R+'!!')
#print(r+'!!')

num=[1,2,3]
popping=num.pop()
print(popping)
popping=num.pop()
print(popping)
popping=num.pop()
print(popping)

print('go!')
